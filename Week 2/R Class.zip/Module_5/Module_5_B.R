##################################################
####                                          ####  
####       R Short Course, Module 5B          ####
####                                          #### 
####  Colorado Cooperative Fish and Wildlife  ####
####              Research Unit               ####
####                                          #### 
####         Author: Brian D. Gerber          #### 
####                                          #### 
##################################################


########################
####  Demonstration ####
########################

    #From a given population matrix, find the finite growth rate.

    #Define a population transition matrix
  
    trans=matrix(c(   0,     0,   0.08,
                    0.80,    0,     0,
                      0,   0.88,  0.94  ),nrow=3, byrow = TRUE)


    #How do we calculate the dominant eiganvalue (popuation growth rate)?
    #From here, let's go to web and look up how to do it. 

    #Compute the finite population growth rate -- lambda.
      eigen(trans)

      eigen(trans,only.values = TRUE)                        #Don't need eigenvectors
  
      eigen(trans,only.values = TRUE)$values[1]              #index to only dominate eigenvalue

      as.numeric(eigen(trans,only.values = TRUE)$values[1])  #only need real number, drop the imaginary part


    #Compare to PopBio package computation
      library(popbio)
      lambda(trans)   #function from popbio to estimate finite population growth

    #Create a function
      new=function(put_matrix_here){
        as.numeric(eigen(put_matrix_here,only.values = TRUE)$values[1])
      }

    #Try out our fancy new function
      new(trans)

    #Our transition matrix assumes all parameters are constant. 
    #Let's relax that assumption by considering Adult survival 
    #as stochastic (the 0.94 value; element [3,3] of trans)

    #First, we need to investigate possible values that capture the uncertainty of Adult Survival. 
    #Consider beta distribution- go look up website and interpret...need two parameters

     shape1=94   #beta distribution parameter
     shape2=6    #beta distribution parameter

     shape1/(shape1+shape2)  #mean of beta distribution

     hist(rbeta(1000,shape1,shape2), xlim=c(0.8,1)) #Plot Distribution

    #Now conduct a simulation and plot lambda, where Adult survival changes stochasticly

      sims=1000               #number of iterations
      lambda=rep(NA,sims)      #store the results
  
      for(i in 1:sims){
        trans[3,3]=rbeta(1,shape1,shape2)
        lambda[i]=new(trans)
      }

    #plot results
      hist(lambda, xlim=c(0.9,1.1))

#Produce a nice looking figure
   
#png("plot.png", width=3300, height=1900,res= 250)
x11()
options(digits=4)
        plot(density(lambda), col=1, lwd=2, xlab=bquote(lambda), main="Population Growth of Species")
        abline(v=mean(lambda),lwd=2, col=2)
        abline(v=median(lambda),lwd=2, col=3)
        legend("topleft",col=c(2,3),lwd=2,
               legend=c(as.expression(bquote(Mean ==.(mean(lambda)))),
                        as.expression(bquote(Median ==.(median(lambda))))),cex=1.3)
    
#dev.off()  #Needs to be run with png function.

########################
####    Exercise    ####
########################

  #1a) Create a vector of length 100, populated with NA's. Define the first element equal to 2.
  #    Next, write a loop to create the sequence, where vec is your vector: 
  #    vec[t=1]=2, vec[t=2]=vec[(t-1)]+2,vec[t=3]=vec[(t-1)]+2,vec[t=4]=vec[(t-1)]+2..... 


  #1b) Using the above population matrix with constant parameters, 
  #   project the population for 20 time steps and plot the total population
  #   size. (Hint: rowSums or colSums may be useful).
  
  #Define N(t) as
    init=c(2000,1500,1000)   #Initial Population Size per age group
  
    trans=matrix(c(   0,     0,   0.08,
                    0.80,    0,     0,
                      0,   0.88,  0.94  ),nrow=3, byrow = T)

  #Hint: First define variables and create a place to store your values
  #Hint: N(t+1)=trans%*%init_pop
  

  #Little Challenge: plot each age groups projection separately on the same plot.


########################
####    Challenges  ####
########################


  #2) Do the same projection while considering Adult survival to vary stochastically.
  #   Plot the total population size for each year (sum of three age groups), for each 
  #   simulation and export as a png
  #   Use these values for beta distribution
    shape1=94
    shape2=6
    #Hint: think about storing data as an array or maybe a list


  #3) Do the simulation again but with less uncertainty (increased precision) around Adult Survival. 
  #   Need to come up with a shape1 and shape2 with the same mean (0.94) but smaller variance.

  #4) Put a single figure together of the plots from "second" and "third" and export as a png.




























########################
####   Solutions    ####
########################

#1a)
a=2
b=rep(NA,100)
b[1]=a
for(i in 2:100){
  b[i]=b[(i-1)]+a
}

b

#1b)
  years=20
  pop=matrix(NA,years,dim(trans)[2])
  pop[1,]=init

  for (i in 2:years){
    pop[i,]=(trans%*%pop[(i-1),])
  }


#Plot total population size over time
plot(rowSums(pop), type="b")


#Plot each age group separately over time
matplot(pop, type="l")


#2)
  sims=100
  years=50
  pop=array(NA,dim=c(dim(trans)[2],years,sims))
  pop[,1,]=init_pop

  for (j in 1:sims){
      trans[3,3]=rbeta(1,shape1,shape2)
      for (i in 2:years){
        pop[,i,j]=(trans%*%pop[,(i-1),j])
      }
    }

  plot(colSums(pop[,,1]), type="l", lwd=2, ylim=c(0,25000))
  for(i in 2:sims){
    lines(colSums(pop[,,i]), lwd=2, col=i)
  }

  png("plot2.png", width=3300, height=1900,res= 250)
    par(mfrow=c(1,1),cex.axis = 1,cex.lab  = 1)
    plot(colSums(pop[,,1]), type="l", lwd=2, ylim=c(0,25000), xlab="Years", ylab="Total Population Size")
      for(i in 2:sims){
        lines(colSums(pop[,,i]), lwd=2, col=i)
      }
  dev.off()


#Third,
  shape3=940
  shape4=60
  pop2=array(0,dim=c(dim(trans)[2],years,sims))
  pop2[,1,]=init_pop

  for (j in 1:sims){
    trans[3,3]=rbeta(1,shape3,shape4)
    for (i in 2:years){
      pop2[,i,j]=(trans%*%pop2[,(i-1),j])
    }
  }

plot(colSums(pop2[,,1]), type="l", lwd=2, ylim=c(0,25000))
  for(i in 2:sims){
    lines(colSums(pop2[,,i]), lwd=2, col=i)
  }


#Fourth,

#png("plot3.png", width=3300, height=1900,res= 250)

win.graph()
  par(mfrow=c(2,1),cex.axis = 1,cex.lab  = 1)
  plot(colSums(pop[,,1]), type="l", lwd=2, ylim=c(0,25000),ylab="Total Population Size", xlab="Years", 
       main=bquote(S["Adult"]~" ~ "~"Beta("~.(shape1)~","~.(shape2)~")"))
  for(i in 2:sims){
    lines(colSums(pop[,,i]), lwd=2, col=i)}
  
  plot(colSums(pop2[,,1]), type="l", lwd=2, ylim=c(0,25000),ylab="Total Population Size", xlab="Years",
       main=bquote(S["Adult"]~" ~ "~"Beta("~.(shape3)~","~.(shape4)~")"))
  for(i in 2:sims){
    lines(colSums(pop2[,,i]), lwd=2, col=i)}

#dev.off()
