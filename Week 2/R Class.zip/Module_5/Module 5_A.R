##################################################
####                                          ####  
####       R Short Course, Module 5A          ####
####                                          #### 
####                                          #### 
##################################################

############################################
## Some Problem Solving when loading data ##
############################################

setwd("")

## The most common errors when loading data are 
## 1. mis-specifying the seperator (delimitor) used
##   in the data (most commonly comma seperated, sometimes tab delimited)
## 2. forgetting to include the header (variable names)
## 3. variables being read into R in the wrong class - motivates a discussion 
##   on classes
## 4. errors in the raw data itself and some discussion about rows and columns
## 
## This module will go through the 4 major errors in detail and discuss how to
## diagnose and solve these issues. 

##
## Part 1, reading in the data
##

##
## reading in a file with no seperator (deliminator)
##
fish.no.sep=read.table(file="fish_data.csv")
head(fish.no.sep) 
dim(fish.no.sep) 
## not specifying that the data is comma seperated causes
## all columns to be joined together


##
## reading in the file with a comma seperator (.csv files are Comma Seperated Value files, CSV)
##

##
## First method with read.table <- sep="," tells the computer that the data
## is comma seperated. For tab deliminated data, use sep="/t"
##

fish.no.header.read.table=read.table(file="fish_data.csv",header=FALSE,sep=",")
head(fish.no.header.read.table) 
## Notice that the columns are now seperate in our data


##
## for .csv files (the most common spreadsheet file type) this is quicker
##

fish.no.header=read.csv(file="fish_data.csv",header=FALSE) 
##read.csv reads in .csv files automatically

head(fish.no.header.read.table)
head(fish.no.header) 
## Notice that read.csv gives the same results as the read.table,
## but is quicker to code (don't have to type sep=",") <- good
## programmers are as lazy as possible ;)

dim(fish.no.header) 
## we now have 7 columns, one for each variable

names(fish.no.header) 
## but the variable names are not right, they are in the first row

fish.no.header[1,] 
## first row of the dataset is the variable names
## To fix this we use header=TRUE in part 2

## 
## Part 2 Including the header
##

fish=read.csv(file="fish_data.csv",header=TRUE)

names(fish) 
## this tells you the variable names

head(fish)

head(fish$Weight) 
#gives the first few observations for the variable Weight in the dataset fish

dim(fish) 
## this dataset has 159 rows (observations) and 7 columns (variables)


##
## Part 1 and 2 are a review of earlier modules, Part 3 is the meat of this module
##

## In R there are many different ways, called classes, that the data are stored.
## These include :
##
## numeric (num) <- continuous quantitative variables
## integer (int) <- discrete quantitative variables
## characters or words <- also called strings (chr) <- qualitative (categorical) variables
## factors (Factor) <- qualitative (categorical) variables
##
## and others that can be determined by using the structure
## str() command
##
## You need to pay attention to the classes of variables. This is one of the easiest ways to
## troubleshoot your code.

##
## The structure command	str()
##

##
## For example, consider the structure of fish
##

str(fish) 

## Weight, all 3 lengths, height, and width are numeric, Species is an integer.
## Do these classes make sense? yes but maybe Species shouldn't be an integer...
## This implies fish species 2 is greater than fish species 1. 

##
## The as. command
##
## as.numeric
## as.integer
## as.vector
## as.factor
## as.character
##

##
## To change classes, use the as. command. For example, to change Species
## to a factor use:
##

fish$Species=as.factor(fish$Species)
str(fish)

## Notice that now fish$Species is now a factor with 7 levels (categories)

fish$Species=as.numeric(fish$Species)
str(fish)

fish$Species=as.character(fish$Species)
str(fish) 
## notice the quotes on fish$Species <- this means the data are now characters
## or strings

fish$Species=as.factor(fish$Species)
str(fish)
## Notice that now fish$Species is now a factor with 7 levels (categories)


##
## The is. command <- like the .as command but returns a true/false answer
## if the variable is of the type of interest
##
## is.numeric
## is.integer
## is.vector
## is.factor
## is.character
## is.na <- asks whether each observation is NA (missing)
##

is.numeric(fish$Weight)
is.numeric(fish$Species)
is.factor(fish$Species)

##
## What do these structures mean? Why bother?
##

layout(c(2,1))
plot(fish$Weight~fish$Species)

plot(fish$Weight~as.integer(fish$Species))

## Because the Species was either a factor or a integer, R behaved differently
## This may look like a small issue for these plots, but it matters greatly 
## for other functions


##
## Part 4 - errors in datasets
##

##
## The biggest indicator of an error in a data set is when a variable 
## is not in the class that you would expect it to be in. This will be 
## made clear in the following example.
##

##
## Let's look at another dataset and look at the effects of 
##
grazing=read.csv(file="grazingeffect2_errors.csv") #default is stringsAsFactors=TRUE
grazing.no.factors=read.csv(file="grazingeffect2_errors.csv",stringsAsFactors=FALSE)

str(grazing) 
## Notice that geology, management and bank angle are factors

str(grazing.no.factors) 
## Notice that geology, management, and bank angle are strings (characters)

##
## Let's look at the effects of geology being a string versus a factor
##

plot(grazing.no.factors$geology~grazing.no.factors$width2depth) 
## When geology is a string, we can't make this plot

par(mfrow=c(1,1)) # same as layout(c(1,1))
plot(grazing$geology~grazing$width2depth) 
## When geology is a factor the plot is made 

## The class of the variable now matters greatly if we want to make a plot

##
## Lets look at str(grazing again)
##

str(grazing) 
## what variable stands out as being in a class that it shouldn't be 

head(grazing$bankangle) 
## looks like a bunch of numbers...

mean(grazing$bankangle) 
## but we can't do numerical operations like find a mean... It must not be numerical...

## Convert grazing$bankangle to numeric

as.numeric(grazing$bankangle) 

## Notice that this doesn't keep the right numbers...
## the first number of grazing$bankangle should be 123.57 not 27 as shown above...
## The 27 comes from it being the 27th factor, to fix the problem we have to do a
## transformation

## First we change the factor into a character (factors are identified by a number,
## characters are identified by their strings) e.g. the 27th factor is for the
## string "123.57"
as.character(grazing$bankangle)

## Then we change the character ("123.57") into a numeric (123.57)
## <- notice no quotes
as.numeric(as.character(grazing$bankangle)) ## Pay attention to the warning!

## save this as a new variable called bankangle.numeric
bankangle.numeric=as.numeric(as.character(grazing$bankangle))
## Pay attention to the warning!

## Notice that we have a missing value (NA) in the data now.
## Let's look at this further
is.na(bankangle.numeric)
## Notice that there is a TRUE in the printout

## Find which observation is the NA using which()
which(is.na(bankangle.numeric) == TRUE) 
## This tells us that the 35th observation is missing.
## Lets look at this in more detail in the original data.

grazing$bankangle[35] 
## 106..7 <- Two decimal points! we have a data entry error!
## The brackets tell R to select the 35th observation of grazing$bankangle

## Two ways to fix this
## One way is to go to excel, delete the extra decimal, and reload the data (I prefer this)
## The other is to fix this in R

bankangle.numeric[35]=106.7 ## overwrite the NA in our variable that we created

bankangle.numeric

grazing$bankangle=bankangle.numeric ## overwrite the variable 

str(grazing) ## Notice that grazing$bankangle is now numeric. Hooray!


##
## rows and columns [rows,columns] - If Time
##

fish[,1] # gives the first column
fish$Weight # compare to the first column

fish[,1]-fish$Weight 
str(fish$Weight)
## All 0's except for the missing value NA <- NA is in the excel data
## Notice how the class for Weight didn't change as this implies the data
## did not have anerror and the NA value is a real characteristic of the data.
## This is in contrast to above where the class of bankangle was not what was
## expected, indicating an error in the data.
##
##

fish[1,] # gives the first row of the data (i.e. observation 1)

fish[5,6] # gives the fifth row of the sixth variable (i.e. the Width of observation 5)
fish$Width[5] #gives the 5th observation of Width, as above


