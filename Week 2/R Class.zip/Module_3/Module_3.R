##################################################
####                                          ####  
####  R Short Course, Module 3:  Graphics     ####
####                                          ####
####                                          ####
##################################################


########################
####  Demonstration ####
########################

getwd()          #find out what directory you're working on   

setwd("C:/Users/bgerber/Google Drive/NRS520/R Class/Module_3")              

####
####  Graphics
####


fish <- read.csv(file="fish_data.csv")
# If you have trouble reading in a file, use "Import Dataset"...
head(fish)  # look at the imported data

#         Code Latin      
#          1   Abramis brama (bream)
#          2   Leusiscus idus (whitefish)
#          3   Leuciscus rutilus
#          4   Abramis bjrkna
#          5   Osmerus eperlanus (smelt)
#          6   Esox lucius (pike)
#          7   Perca fluviatilis (perch)

# Weight      Weight of the fish (in grams)
# Length1     Length from the nose to the beginning of the tail (in cm)
# Length2     Length from the nose to the notch of the tail (in cm)
# Length3     Length from the nose to the end of the tail (in cm)
# Height%     Maximal height as % of Length3
# Width%      Maximal width as % of Length3


# Basic plotting in R
# ?plot()             

plot(fish$Weight, fish$Length3)   # scatterplot of x and y

# another way to create the scatterplot, plot(y ~ x)
plot(Length3 ~ Weight, data=fish)

# add points to a plot
points(fish$Weight, fish$Length1, pch=6, col="purple")  # points(x, y)

# specify that you want a line graph type="l", lwd= line thickness
plot(fish$Length1, fish$Length2, type="l", lwd=2)


?plot.default  # get some of the options for plot
?par  # get all of the different options for the plot                


# boxplot(y ~ x)
# creates a box and whisker plot of the given grouped values

# boxplot of Weight values by species
# (boxplot is useful for a "categorical" variable)
boxplot(Weight ~ Species, data=fish)   



####
####  Symbols and colors
####

?par    # set graphical parameters

plot(fish$Height, fish$Weight, pch=16)  # filled dots as symbols
?pch  # to see all possible symbols

plot(fish$Height, fish$Weight, pch=16, cex=2) 

plot(fish$Height, fish$Weight, col="purple", pch=16, cex=2)   # color as a name

plot(fish$Height, fish$Weight, col=4, pch=16, cex=2)   # color as a number

plot(fish$Height, fish$Weight, col=as.numeric(fish$Species), pch=16, cex=2)  # color defined by data



####
####  Legends
####

with(fish, plot(Weight, Height, ylim=c(5, 45)))
with(fish, points(Weight, Width, pch=10, col="purple"))

# Add a legend specifying the coordinates (text)
legend(1400, 40, legend="Height", pch=1)  

legend(1400, 40, legend=c("Height", "Width"), pch=c(1, 10), col=c("black", "purple"))           

?legend


# add the legend by clinking for its location
legend(locator(1), legend=c("Height", "Width"), pch=c(1, 10), col=c("black", "purple"))  

# also add a title
title("Fish Height vs. Weight")


##
##  Other plot types
##

# creates a matrix of scatterplots
pairs(fish)

# scatterplots for a subset of the variables
pairs(fish[, c(1, 2, 5, 6)]) 



#?hist            #histogram of the given data values

hist(fish$Width)                 # histogram of Width

hist(fish$Width, breaks=20)       # histogram of Width with 20 breaks

hist(fish$Length3, breaks=30, col="blue", 
     main="Lengths", col.main="blue", xlab="Total Length (cm)")



y <- rnorm(100)  # generate "observations" of a random variable
hist(y, breaks=20, col=8)

# change the histogram into a density function
hist(y, breaks=20, prob=TRUE, col=8)

# add a density curve
lines(density(y), col=4, lwd=2)


# example with fish data
hist(fish$Width, prob=TRUE, col=3, lwd=2)
lines(density(fish$Width), col=4, lwd=2)
#?density  # you can change the "smoothness" of the curve



# adding a line to a scatterplot
plot(Length1 ~ Length3, data=fish)
abline(-0.425, 0.854, col="red")  # adds a straight line: y = a + bx
?abline
curve( -0.425 + 0.854*x, add=TRUE, lwd=3, lty=2)  # adds any line: y = ???




             


####################
####  Exercises ####
####################

####
####  more plotting options
####

plot(fish$Height, fish$Width)  # default

# Specify many parameters of a plot
plot(fish$Height, fish$Width, type="p", pch=2, col=3, main="Fish data", 
     xlim=c(10, 50), ylim=c(5, 25), ylab="Height", xlab="Width")  # as desired

# You can modify the axis of a plot: color or font, etc. 1=x-axis, 2=y-axis
axis(1, col="blue", font.axis=8, lwd=3)         

# You can add any text to anywhere specified on the graph by x and y
text(40, 20, "C", cex=2)                  



###
### Add a legend-- try with new data set
###

# Read in the Manitoba lakes data
lake_data <- read.table(file="lake_data.txt", header=T, sep=",")
head(lake_data)


# plot using filled symbols and in red
plot(Turbidity ~ Wind, data=lake_data, pch=15, cex=1, col="red") 

# add points for Wind in blue
points(lake_data$Wind, lake_data$Temp, pch=20, cex=2, col="blue") 

# Add a legend specifying the coordinates (text)
legend(15, 140, legend=c("Turbidity", "Temp"), 
       pch=c(15, 20), cex=1, col=c("red", "blue"))           

# plot using filled symbols and in red
plot(Turbidity ~ Temp, data=lake_data, pch=15, cex=2, col="red") 

# add points for Wind in blue
points(lake_data$Temp, lake_data$Wind, pch=20, cex=2, col="blue")                    

# add the legend by clinking for turbidity
legend(locator(1), "Turbidity", pch=15, col="red", cex=1)    
# (now click on plot where you would like the legend to be located)

# add the legend for Wind, but without the outline box
legend(locator(1), "Wind", pch=20, col="blue", bty="n", cex=1) 


####
####  Multiple plots in one window
####

par(mfrow=c(1, 2)) # matrix of 1 row, 2 columns ==> 2 plots next to each other

plot(Algae ~ Temp, data=lake_data)
plot(Wind ~ Temp, data=lake_data)

par(mfrow=c(1, 1))  # change window back to default for future plots

####
####  Types of plots
####

primates <- read.table(file="primates.txt", header=T, sep=",")
head(primates)
dim(primates)  # it is a small data set with only 5 rows
attach(primates)
# BE SURE TO DETACH AT THE END!

# plot 
plot(Bodywt, Brainwt, xlim=c(0, 300), 
                    xlab="Body weight (kg)", ylab="Brain weight (g)", main="Monkeys") 
# add text to identify each point
text(x=Bodywt, y=Brainwt, labels=row.names(primates), pos=4) 


# Create a pie chart 
#?pie
pie(Bodywt, labels=row.names(primates), col=c(10:15) ) 
                   
detach(primates)


####
####  Error bars
####

# Read in distribution data for a fish community in a stream, 
species <- read.csv("Comm_data.csv")
head(species)


# C_UPS = capture probability upstream; 
# C_DWN = capture probabilitiy downstream,
# Each row is a species, 30 species total
# Hab_class 1 = fast flowing; 2 = medium flow; 3 = pool 


attach(species) 
# BE SURE TO DETACH AT THE END!

# with attach, can access the columns of the data frame directly
hist(C_DWN)

unique(Hab_class)  # confirms that there are 3 habitat classes


# Plot capture probability for each species, with symbol and color defined by habitat class
plot(C_UPS ~ C_DWN , type="p", pch=as.numeric(Hab_class), col=as.numeric(Hab_class), 
     xlab="Capture probability downstream", ylab="Capture probability upstream", 
     xlim=c(0, 1), ylim=c(0, 1)) 

# add error bars to show the standard deviation associated with each probability

# Using the default settings... doesn't look quite right
arrows(C_DWN, C_UPS - C_UPS_SD, C_DWN, C_UPS + C_UPS_SD) 

# Change the function arguments to look like error bars
# (First redraw the plot)
plot(C_UPS ~ C_DWN , type="p", pch=as.numeric(Hab_class), col=as.numeric(Hab_class), 
     xlab="Capture probability downstream", ylab="Capture probability upstream", 
     xlim=c(0, 1), ylim=c(0, 1)) 
arrows(C_DWN, C_UPS - C_UPS_SD, C_DWN, C_UPS + C_UPS_SD, 
       code=3, angle=90, length=0.1, col=as.numeric(Hab_class)) 
arrows(C_DWN-C_DWN_SD, C_UPS, C_DWN+C_DWN_SD, C_UPS, 
       code=3, angle=90, length=0.1, col=as.numeric(Hab_class)) 


# We could have also created a function to draw in the error bars with the defaults that we want.

# Function for plotting error bars in an xy scatter plot
# want error bars of different dimensions for x and y
xy.error.bars <- function(x, y, xbar, ybar){
  arrows(x, y-ybar, x, y+ybar, code=3, angle=90, length=0.1)
  arrows(x-xbar, y, x+xbar, y, code=3, angle=90, length=0.1)
}

plot(C_UPS ~ C_DWN , type="p", pch=as.numeric(Hab_class), col=as.numeric(Hab_class), 
     xlab="Capture probability downstream", ylab="Capture probability upstream", 
     xlim=c(0, 1), ylim=c(0, 1)) 
xy.error.bars(C_DWN, C_UPS, C_DWN_SD, C_UPS_SD)

detach(species)  # always clean-up and detach data frames!!!



####
####  GGplot package
####

library(ggplot2)    
# This library makes some plots that are similar to the basic plots
#  Its plots tend to be more visually pleasing
#  It also creates more complicated plots fairly easily

# a histogram
qplot(Turbidity, data=lake_data)

# a scatterplot
qplot(Temp, Algae, data=lake_data)

# box and whisker plot for Turbidity by Month
qplot(factor(Month), Turbidity, data=lake_data, geom="boxplot" )

# Similar, but look at the data directly with a dotplot:
qplot(Month, Turbidity, data=lake_data)
      

# Look at Turbidity vs. Algae, separate graph for each month
qplot(Algae, Turbidity, data=lake_data, facets= . ~ Month)


# Density plot
ggplot(lake_data, aes(x=Turbidity)) + geom_histogram(aes(y=..density..), fill="grey") + geom_density(lwd=2) 
# gets a warning because of NA's in the data.

# Redraw last plot, but with a less smooth density estimate...
last_plot() + geom_density(adjust=1/2, col="red", lwd=1.5)



####################
####  Challenge ####
####################

# 1: Create a regular scatterplot of 'Weight' as a function of 'Length1', using
#    big triangles to plot the values. Give the graph a main label, i.e. a title, in a bigger
#    font than the axis labels.  Also add a legend to the plot.

# 2:  Within 1 window, show 3 plots:  Weight versus Length1, Weight versus Length2, 
#     and Weight versus Length 3.  In each plot, use different colors and/or symbols to identify 
#     the fish species associated with each point.

# 3: Create a box and whisker plot of capture probability downstream by habitat class for the fish
#    community data. 

# 4: Plot 40 uniform random variables on [-1,2], with the y-axis set at -10 and 20. 

