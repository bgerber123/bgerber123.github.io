
################################################################
####                                               	      	####  
####  R Workshop, Module 4 Extra Exercises                	####
####                                                        ####
################################################################

###############  Logistic Regression  ################################

## read in P/A data of lichen
lichen=read.csv("lichentopo.csv")
head(lichen)            # look at variables
dim(lichen)             # dimension of data

############ Exploratory Data Analysis  ###################
attach(lichen)          # shortcut so you can just call variable names

# if you want to split data by presence/absence:
pres=lichen[which(LOREG==1),]
head(pres)
abs=lichen[which(LOREG==0),]
head(abs)

#### create table of descriptive stats  ####
#### use tapply or apply to go across variables
mean.elev=tapply(ELEV,LOREG,mean)     # get mean for elev in different LOREG
n.elev=tapply(ELEV,LOREG,length)      # get elev length for LOREG
var.elev=tapply(ELEV,LOREG,var)       # get variance
se.elev=sqrt(var.elev/length(ELEV))              # must manually compute SE - no R function
cbind(mean.elev,se.elev,n.elev)       # put them all in one nice table

### or include all 3 variables  #########
mean=apply(lichen[,-1],2,mean)     # make col of means
st.dev=apply(lichen[,-1],2,sd)     # col of standard deviations           
cbind(mean,st.dev)               # combine into table

## visual graphics
boxplot(pres$ELEV,abs$ELEV)
boxplot(pres$PCSLOPE,abs$PCSLOPE)
boxplot(pres$TASPECT,abs$TASPECT)

##################   Fit Models   #########################
#### Fit logistic regression model w/ all variables  ####
lichen.log123=glm(LOREG~ELEV+ PCSLOPE+ TASPECT, data=lichen,family="binomial")
summary(lichen.log123)

## problems w/ correlation?
library(HH)  # might need to install this package on your computer
vif(lichen.log123)  # gives VIF values for coefficients


## fit smaller model w/out TASPECT
lichen.log12=glm(LOREG~ELEV+ PCSLOPE, data=lichen,family="binomial")
summary(lichen.log12)

## fit model w/ just ELEV
lichen.log1=glm(LOREG~ELEV, data=lichen,family="binomial")
summary(lichen.log1)

## fit logistic model w/ probit link
lichen.log1.probit=glm(LOREG~ELEV,data=lichen,family=binomial(link=probit))
summary(lichen.log1)

###  Estimate odds ratio
exp(confint(lichen.log123)) # notice the CI for TASPECT covers 1

###################    ANOVA    ################################
graze=read.csv("grazingeffect2.csv",header=T) # bring data in
library(car)
attach(graze) 


### perform descriptive stats & put into table
fmean=tapply(bankangle,mngmt,mean) 
fn=tapply(bankangle,mngmt,length)  # no. of observations
fvar=tapply(bankangle,mngmt,var) 	# variance
fse=sqrt(fvar/fn)	
f=cbind(fmean,fn,fvar,fse)
colnames(f)=c('Mean','n','Variance','SE')
f

#####  model fit

m1=aov(bankangle~mngmt,data=graze)     # use aov() like lm     

# need to check assumptions -  look at residuals
par(mfrow=c(2,2))      # get ready for 2x2 plot
plot(m1)
# upper right plot gives normality (Q-Q plot)
# upper left plot assess the equality of treatment variances assumption

## Look for differences in mgmt with Tukey's pairwise comparisons
TukeyHSD(m1)
plot(TukeyHSD(m1))

