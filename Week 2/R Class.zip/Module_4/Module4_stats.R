##################################################
####                                          ####
####  R Short Course, Module 4                ####
####                                          ####
####                                          ####
##################################################


########################
####  Demonstration ####
########################

#####
#####  Simulate Data
#####

n=50
X=matrix(0,n,2)         # 10 by 2 matrix of zeros.
X[,1]=rep(1,n)          # replace first column with ones.
X[,-1]=rnorm(n)         # fill cols 2 and 3 with iid std norm rvs.
head(X)                 # check out design matrix
beta=c(.5,-2)           # create vector of true coefficients.
y=beta[1]*X[,1] + beta[2]*X[,2] + rnorm(n,0,.75)     # simulate response variable.
y= X%*%beta+rnorm(n)    # matrix notation

pairs(cbind(y,X))       # view pairwise scatterplots

#####
#####  Summary Statistics
#####

mean(y)      # compute sample mean
median(y)    # compute sample median

mean(X)      # mean of over whole matrix

min(y)       # sample minimum
max(y)       # sample maximum
range(y)     # both min and max.

quantile(y,0.5)   # compute sample median using quantile
quantile(y,c(0.25,0.75))   # compute sample quartiles

var(y)       # sample variance of y
sd(y)        # sample standard deviation of y
sqrt(var(y)) # another method for computing std. dev.

var(X)       # variance of a matrix is covariance
cov(X)       # covariance matrix
cor(X)       # correlation matrix
diag(cov(X))    # diagonal elements of matrix
diag(3)      # creates an identity matrix of size dimension 3 by 3. 

summary(y)   # provides a set of summary statistics for y. 
summary(cbind(y,X))   # also works for matrices (on the columns)

#####
#####  Linear Regression using Built-In Functions
#####

y.df=data.frame(cbind(y,X[,2]))         # put variables in data frame (not necessary, but convenient)
names(y.df)=c("y","x")                  # provide names

y.lm=lm(y ~ x, data=y.df)               # fit linear regression model
summary(y.lm)                           # view generic results of fit
anova(y.lm)                             # view ANOVA table of results
confint(y.lm)                           # confidence intervals for model coefficients
AIC(y.lm)                               # compute AIC 
plot(y.lm)                              # cycle through regression diagnostic plots

y.resids=resid(y.lm)                    # obtain residuals from model
plot(y.resids)
abline(h=0)

y.fitted=predict(y.lm)                  # obtain fitted values and plot against y
plot(y,y.fitted,asp=TRUE)
abline(0,1)

x.pred=seq(-5,5,,10)                           # create values of x where predictions are desired
y.pred=predict(y.lm,newdata=list(x=x.pred))    # obtain predictions
cbind(x.pred,y.pred)                           # view x and y for predictions
plot(y~x,data=y.df)
points(x.pred,y.pred,pch=21,col=2,type="o")    # plot predictions on scatterplot of data

#####
#####  Alternate model specifications
#####

y.mean.lm=lm(y~1,data=y.df)             # fit linear regression with intercept only (mean model)
summary(y.mean.lm)

y.noint.lm=lm(y~0+x,data=y.df)          # fit linear regression with no intercept and x only
summary(y.noint.lm)

y.xsq.lm=lm(y ~ x + I(x^2),data=y.df)   # fit linear regression with intercept and added quadratic term for x
summary(y.xsq.lm)

anova(y.mean.lm,y.lm)                   # F-test for variable significance, smaller model first

####################
####  Exercises ####
####################

####
#### Read in sculpin data
####

sculpin.df=read.csv("sculpineggs.csv")
sculpin.df
plot(NUMEGGS~FEMWT,data=sculpin.df)

####
#### Fit Linear Model
####

sculpin.lm=lm(NUMEGGS~FEMWT,data=sculpin.df)
summary(sculpin.lm)
plot(NUMEGGS~FEMWT,data=sculpin.df)
abline(sculpin.lm,col=1)

newdata=data.frame(FEMWT=28)
predict(sculpin.lm,newdata, interval="predict")  # get CI for new prediction

####
#### Fit Generalized Linear Model using Gaussian family (should be same results as linear model)
####

sculpin.glm.gaus=glm(NUMEGGS~FEMWT,family=gaussian(),data=sculpin.df)
summary(sculpin.glm.gaus)

####
#### Fit Generalized Linear Model using Poisson family with log link for counts
####

sculpin.glm.pois=glm(NUMEGGS~FEMWT,family=poisson(),data=sculpin.df)
summary(sculpin.glm.pois)

####
#### Fit Generalized Linear Model using Poisson family with identity link
####

sculpin.glm.pois.iden=glm(NUMEGGS~FEMWT,family=poisson(link="identity"),data=sculpin.df)
summary(sculpin.glm.pois.iden)

####################
####  Challenge ####
####################

# 1: Which of the models in the exercises provides the best fit to the data?

# 2: Plot the fitted values against the residuals for the sculpin.lm model.

# 3: What is the SSE for the sculpin.lm model?  What is the p-value for the significance of FEMWT in this model?

# 4: Create a table of descriptive statistics for the sculpin data including mean and standard deviation.

# 5: Obtain predictions and 95% prediction intervals for sculpin eggs at female weights of 20 and 30.


