##################################################
####                                          ####  
####  R Short Course, Module 2                ####
####                                          #### 
####                                          #### 
##################################################

####Working directoy

getwd()          #find out what directory you're working on   

#setting a new working directory in a PC (Session -> Set Working Directory -> Choose folder)

setwd("C:/Users/bgerber/Google Drive/NRS520/R Class/Module_2")

#####get what files are in the working firectory
dir()

#Good data management: no spaces within names
#names of objects not similar to names of functions, etc

####
####  Import of data
####

##many ways data can be imported
##text files, csv, etc.  
##view some from the working directory

#Open data.txt from the directory
#reads in the data and skips headers

DATA <- scan(file ="data.txt",what=list("",0,0,""),sep="\t",skip=1) 

#We specified that the first and fourth elements are text
# and the third and fourth are numbers

class(DATA)
DATA  ##we read the file in as a list! 
DATA[[3]]

##We can specify what separates the components of the file (sep="\t")
##Or we can use a specific 'read.table' command

# ?read.table     #reads any table, can specify which format
# ?read.csv       #fields are separated by a comma
# ?read.csv2      #fields are separated by semicolons
# ?read.delim     #Tab delimited files
# ?read.delim2    #Tab delimited with periods as commas

#more flexible with text files
data1 <- read.table("data.dat", header=TRUE)   #read in data with a header row                           

head(data1) ##shows the first elements of an object

#specify that the elements are separated by a comma (.csv)
data2 <- read.table("data.csv", header=T, sep=",")  

head(data2)           #returns the first part of an object

names(data2)          #lists column names of an object

data3 <- read.csv("data.csv")
names(data3) 

#from RStudio- use console of the left (Import data set)
#can set the header, sep, etc.


####
####  Exporting data
####

#?write               #writes data (matrix) into any file
#?write.table         #writes a file into the working directory


write.table(data1, file="data_export.csv", sep=",", col.names=TRUE,row.names=FALSE)
                 
####
####  Saving and loading
####

#Rhistory: All of the commands I have sent to R
#workspace: All of the objects that I have created during the session get stored in the workspace

#?save              #saves all of the data in the workspace
#?save.image        #faster way to save my current workspace

#saves the workspace, but often hidden
save.image()        

#saves the workspace into a list                        

save(list=ls(all=TRUE), file="Module2.RData") 

#quicker way to save the workspace

save.image(file="Module2b.RData")    

dir() #check to see if the files were loaded properly

#?load()                        #command to load any files on a workspace

#Clear All from the workspace
rm(list=ls())

#can load a workspace from the directory
load(file="Module2b.RData")                                               
                                    
####
####  Data manipulations
####

#A review of indexing

# $            access component of an object
# Z_list[[i]]  access the ith element of a list
# X[i]         access the ith element of X
# X[a,b]       access row a, column b element of matrix/data frame X
# X[,b]        access column b of matrix/data frame X
# X[a,]        access row a of matrix/data frame X

DATA
DATA[[3]]

data2[,2:3]##access only the second and third columns of data2


####
####  Boolean operations
####

# <- assignment: required for functions
# =  alternative assignment 
# <  less than
# >  greater than
# <= less than or equal to
# >= greater than or equal to
# == equal to
# != not equal to

Y <- 4
Y
Y = 4
Y
Z <- 6

Y == Z  #I am asking if Y is equal to Z, and it will return FALSE

Y < Z


?which    #an option for subsetting and indexing    

Mat <- matrix(1:18,nrow=3,ncol=6)
Mat
which(Mat >= 4)
which(Mat >= 4, arr.ind=T)
which(Mat > 4 & Mat <= 8)

Mat.vec <- Mat[2,]
Mat.vec

index <- which(Mat.vec>=8)

Mat.vec[index] <- 8
Mat.vec

####
####  Subsetting
####

#reading in data for a turtle to use using 'subset'
turtles <- read.table(file="Turtle.txt", header=T)
names(turtles)
head(turtles)

#subset for females
fem.turtles <- turtles[which(turtles$sex =="female"),]    

#can subset just one factor based on another
#Here we want to know the mean weight of all females 
mean(turtles$weight[which(turtles$sex =="female")]) 

#?subset

unique(turtles$sex)

male.turtles <- subset(turtles,sex != "male")             #another way to subset for females

male.turtles2 <- turtles[which(turtles$sex !="male"),]

new.turtles <- subset(turtles, weight >= 10) #subsetting by weight 
head(new.turtles)

####
####  Sorting
####

#?sort
#?rank

?order

#sorting in order of tag number
turtles1 <- turtles[order(turtles$tag_number),]

# sorting in reverse order
turtles2 <- turtles[rev(order(turtles$tag_number)),] 

#sorting by 1+ factors
turtles3 <- turtles[order(turtles$sex,turtles$weight),] 


#Look at the column names
colnames(turtles)

#chage the first column name
colnames(turtles)[1]=c("tag")
colnames(turtles)



####################
####  Challenge ####
####################

# 1: Create a new data frame by reading in the file "Comm_data.txt" in your module folder.
#    For the new data frame, bind only the following columns: Class, C_DWN, C_UPS, and rename the 
#    columns as: "Class","Down_stream", "Up_Stream".

# 2: Read in the file "Turtle.txt', and explore the data.  Create a new data frame
#    without any missing values for length, width and weight, and save it as a tab 
#    delimited text file in the workspace. 
#    



