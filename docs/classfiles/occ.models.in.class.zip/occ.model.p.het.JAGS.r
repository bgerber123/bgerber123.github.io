model {
  # Priors
  psi~dunif(0,1)
  mu.alpha ~ dnorm(0,0.01)
  tau.alpha = 1/var.alpha
  var.alpha ~ dunif(0,1)

# Loop over sites	
for(i in 1:n.sites){
  z[i] ~ dbern(psi)
  # Loop over occasions within sites			
  for(j in 1:n.visits){
    logit(p[i,j]) <- alpha[i,j]
    alpha[i,j] ~ dnorm(mu.alpha,tau.alpha)
    peff[i,j] <- p[i,j]*z[i]
    y[i,j] ~ dbern(peff[i,j])
  }# j loop
} #i loop
}