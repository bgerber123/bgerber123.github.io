model {
  # Priors
  psi~dunif(0,1)
  p~dunif(0,1)
  
  # Loop over sites	
  for(i in 1:n.sites){
    z[i] ~ dbern(psi)
    y[i] ~ dbinom( p*z[i],N[i])
  } #i loop
}