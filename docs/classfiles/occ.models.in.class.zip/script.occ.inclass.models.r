# Bayesian Occupancy model- single species / single season

# Libraries
library(rjags)

#Read data
bunny=read.csv("detection_nondetection_bunny.csv")

#Look at the data
head(bunny)

##########################################################
# First in class model - Binomial likelihood and count data
# summed across occasions for each site

# First setup the data  
  bunny.data = cbind(bunny$Observed1,  bunny$Observed2)
  n.sites = nrow(bunny.data)
  n.visits = ncol(bunny.data)

# Package the data into a list    
  data = list(
              y = apply(bunny.data,1,sum),
              n.sites = nrow(bunny.data),
              N = rep(2,nrow(bunny.data))
  )

# We do not always need to feed in initial values, but it can help; we always need to initialize z to match our data
inits <- function(){list(z=apply(bunny.data, 1, max), 
                         p=runif(1), psi=runif(1))}



# Settings for MCMC chains
  nchains<-3
  niter<-2000
  nburn<-500
  nthin<-1

jm=jags.model(file="occ.model.binomial.JAGS.r", data=data, inits=inits, n.chains=nchains, n.adapt=2000)

# Run the burn-in portion of the model
  update(jm, n.iter=nburn)

# Tell JAGS which parameters to save
  params = c("p","psi")  
  
# Sample from the posterior
  M1 = coda.samples(jm, variable.names=params, n.iter=niter, thin=nthin)


  plot(M1)  

##########################################
##########################################

# Second model inclass- separate detection probability
# parameters per occassion
  
  bunny.data = cbind(bunny$Observed1,  bunny$Observed2)
  n.sites = nrow(bunny.data)
  n.visits = ncol(bunny.data)

# Package the data into a list    
  data=list(
    y=bunny.data,
    n.sites=nrow(bunny.data),
    n.visits=ncol(bunny.data)
  )

# Settings for MCMC chains
  nchains<-3
  niter<-2000
  nburn<-500
  nthin<-1

# Tell JAGS which parameters to save
  params=c("p","psi")

# We do not always need to feed in initial values, but it can help; we always need to initialize z to match our data
  inits <- function(){list(z=apply(bunny.data, 1, max), 
                           p=runif(2), psi=runif(1))}


jm=jags.model(file="occ.model.p2.JAGS.r", data=data, inits=inits, n.chains=nchains, n.adapt=2000)

# Run the burn-in portion of the model
  update(jm, n.iter=nburn)

# Sample from the posterior
  M1 = coda.samples(jm, variable.names=params, n.iter=niter, thin=nthin)


plot(M1)  
###################################################

# Third model in class model - accounting for heterogeneity in detection
# probability by sites and occasions using a 'random effect'

# Package the data into a list    
data=list(
  y=bunny.data,
  n.sites=nrow(bunny.data),
  n.visits=ncol(bunny.data)
)

# We do not always need to feed in initial values, but it can help; we always need to initialize z to match our data
  inits <- function(){list(z=apply(bunny.data, 1, max), 
                           psi=runif(1))}


#note that this model is more difficult to fit
  
# Settings for MCMC chains
  nchains <- 1
  niter <- 20000
  nburn <- 3000
  nthin <- 10

  params=c("mu.alpha","tau.alpha","psi")


jm = jags.model(file="occ.model.p.het.JAGS.r", 
              data=data, inits=inits, n.chains=nchains, 
              n.adapt=5000)

# Run the burn-in portion of the model
  update(jm, n.iter=nburn)

# Sample from the posterior
  M1 = coda.samples(jm, variable.names=params, 
                    n.iter=niter, thin=nthin)


plot(M1)  


