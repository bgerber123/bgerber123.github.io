################################################################################
#                                                                              #
#                               DATA MANIPULATION                              #
#                                                                              #
################################################################################

# ______________________________________________________________________________

 #  IMPORTING DATA INTO R
     
   # 2 OPTIONS:
     
     # 1. SET UP THE DIRECTORY FIRST AND THEN IMPORT THE DATA
       getwd()
       setwd("")
       # In this case:
       # No need to specify the file name, you are just specifying the folder
       # in which the file is located, also called the directory
       
       # Another way to set the directory:
       lab3=""
       setwd(lab3)
            
       # Now that we are located in the right directory, we still need to read the data:
       # if that file was saved as a comma delimited csv file, where columns where 
       # separated by commas then we need to specify sep=","
       # header = TRUE indicates that in my excel file, each column as a name  
       dat.csv <- read.csv("lsgo_measures.csv", header=TRUE, sep=",")
       head(dat.csv)           
          
     # 2. SET UP THE DIRECTORY WHILE EXPORTING THE DATA
       dat.tab <- read.table("X:\\....\\lsgo_measures.csv", header=T,sep=",")
       dat.tab
 
   # There are a lot more options to read in the data depending on data format:
     ?read.table

   
# ______________________________________________________________________________

 # DATA MANIPULATIONS
   
   # READING AND VISUALISING THE DATA
     # About the data:
     # it's a snapshot of data on lesser snow geese. They migrate and breed each 
     # year in northern Manitoba Canada, along the Hudson bay. 
     # As par of or banding efforts, we collect lesser snow geese gosling 
     # measurements in the summer.
     # Let's import and take a look at the data: 
     dat <- read.csv("lsgo_measures.csv", header=TRUE, sep=",")
     dat        
     head(dat)     # Shows the first few rows of the dataset
     tail(dat)     # Shows the last few rows of the dataset
     summary(dat)  # Summarizes the information in the dataset within each column
     dim(dat)      # Provides the dimensions of the dataset
     names(dat)    # Provides the names of the elements in the data frame
     is.data.frame(dat) # Verifies that this object is indeed a data.frame
     
   # $ 
     # To look at a specific vector within this data set, we have to use the $ sign:
     dat$SEX      # Males and females
     dat$AGE      # G stands for goslings
     dat$HABITAT  # Mass in grams
     unique(dat$HABITAT) # the unique function isolate how many levels are 
                         # present within an object
     
   # DATA TYPES  
     dat$HABITAT   # Character vector
     dat$MASS      # Numeric vector 
     logic.height <- dat$HEAD_HEIGHT>92
     logic.height  # Logical vector
     
   # MISSING DATA  
     is.na(dat)           # Checking for missing values
     dim(dat)
     dat <- na.omit(dat)  # removing missing values
     is.na(dat)
     dim(dat)
     
   # LIST FUNCTION
     # Creates a list that provides basic information about the data:
     listdat <- list(dat,summary(dat),names(dat))
     listdat 
   
   # FACTOR
     # is habitat a factor?
     is.factor(dat$HABITAT) # Yes
     # how many levels?
     factor(dat$HABITAT)    # 2 levels: poor and good
        
   # SORTING / ORDERING DATA
     sorted.age <- sort(dat$AGE)
     sorted.age 
     ordered.CWS <- sort(dat$CWS)
     ordered.CWS     
   
   # SUBSET FUNCTION 
     # e.g. Only select information that pertains to females in the dataset: 
     females <- subset(dat,dat$SEX=="F")
     females
     females$SEX
     # e.g. Only select information that pertains to goslings that weight>1000gr:
     fatgosies <- subset(dat,dat$MASS>1000)
     fatgosies
     summary(fatgosies$MASS)
   
   # LOGICAL OPERATORS: ! & |
     # e.g. Delete all females and associated information (rows) from the dataset:
     males_only <- dat[(!dat$SEX=='F'), ]
     males_only
     # or: 
     males_only2 <- dat[(dat$SEX=='M'), ]
     males_only2   
     # e.g. Visualize individuals who have a HEAD_HEIGHT<90 and TARSUS_LENGTH>90
     dat[((dat$HEAD_HEIGHT < 91) & (dat$TARSUS_LENGTH > 89)), ]   
   
   # ATTACH / DETACH FUNCTIONS
     # Having to use the dollar sign to recall a specific column in a dataset
     # can be inefficient (eg. fatgosies$MASS)
     attach(fatgosies)
     MASS
     summary(MASS)   # No need to type fatgosies$MASS anymore! I "attached"
                     # information pertaining to fatgosies to R's memory
     
     # If you are uncomfortable with this and want to go back to the dollar sign 
     # approach you can always:
     detach(fatgosies)# detach the dataset from r' internal memory
     MASS             # Now R doesn't know what you are talking about anymore                  
     fatgosies$MASS
     attach(dat)      # Let's go back to the original dataset
     dat

   # APPLY FUNCTION                                          
     # apply(X, MARGIN, FUN, ...)
     # X is an array or matrix
     # MARGIN is a variable that determines whether the function is applied 
       # over rows (MARGIN=1), columns (MARGIN=2), or both (MARGIN=c(1,2))
     # FUN is the function to be applied
     # Create the matrix
     head(dat)
     measures <- dat[ ,5:8]    # note that when you don't specify a row number, 
                               # all rows are selected
     measures
     apply(measures,2,mean)    # calculate the mean across columns for this dataset
       
   # LOOPS
     attach(dat)
     summary(HEAD_HEIGHT)
     # Create a new variable that divides goslings' head height into 2 groups: 
     # if head height is less than the mean, the individual will be 
     # assigned to the "small head" group
     # if head height is equal or superior to the mean, 
     # the individual will be assigned to the "large head" group.
     # There are multiple ways to do this:
     L <- length(HEAD_HEIGHT)
     headL <- rep(NA,L)
     for (i in 1:L) {
       if (HEAD_HEIGHT[i] < mean(HEAD_HEIGHT)) headL[i]<-"small head"
       else  headL[i]<-"large head"
     }  
     headL
         
   # WRITTING FUNCTIONS
     # Write a function that will convert head length from mm to cm
     convert.to.cm <- function(x) {
     x <- x/10
     return(x)
     }
     convert.to.cm(HEAD_HEIGHT)
     HEAD_HEIGHT_cm <- convert.to.cm(HEAD_HEIGHT)
              
# ______________________________________________________________________________

 # EXPORTING DATA OUT OF R

     write.table(dat,"output.txt")
     write.table(dat,"output.csv")
     write.table(dat,"output.xls") 
# ______________________________________________________________________________  
 
   # PACKAGES
    
     # DOWNLOADED PACKAGES
       # Set of packages loaded on startup is by default
       getOption("defaultPackages")
        
     # LIST OF AVAILABLE PACKAGES
       # http://cran.r-project.org/web/packages/
    
     # DOWNLOADING A PACKAGE: MULTIPLE OPTIONS
       
       # 1. INSTALL THE PACKAGE: 
         # go to R --> Packages --> Install packages
         # Select Cran Mirror
         # Select package: I selected 'survival'
         # Look at the R window: 
           # --- Please select a CRAN mirror for use in this session ---
 
       
       # 2. LOAD THE PACKAGE
         # go to R --> Load package --> select the package you need 
         # you will find in there all of the previously installed packages       
      
       # MORE OPTIONS AT: http://cran.r-project.org/doc/manuals/R-admin.html
       # also available under MODULE 3 / Readings
 
     # HELP WITH PACKAGES 
       help(package="survival")

# ______________________________________________________________________________
   

