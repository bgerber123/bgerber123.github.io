################################################################################
#                                                                              #
#                        FUNDAMENTALS OF THE R LANGUAGE                        #
#                                                                              #
################################################################################

# ______________________________________________________________________________

 # SIMPLE CALCULATIONS

   # The R calculator
     # Uses standard operators: +, -, *, /, ^
     # Observes normal order of operations.
     # Make sure to include all "*". Do 3*(4+2), NOT 3(4+2).
     # Use parentheses ( ) as needed.
     # Use up arrow key to recall previous entries

   2+3
   2**8          # power function
   2^8           # equivalent to power function 
   sin(0.5*pi)   # standard functions: sin, cos, log, exp, etc.
   (2+3)*4       # use parentheses if needed
   sqrt(9)       # square root of 9
   sqrt(1:10)    # ":" indicates a sequence, in this case ranging from 1 to 10
                 # here we are taking the square root of each number in that 
                 # sequence
   
   # NOTES
   # Anything preceded by # is not read by R
   # use '#" to comment your code, as i am doing right now
   # One has to use a dot (.) to separate decimals, not a comma (,)

# ______________________________________________________________________________

 # CREATING OBJECTS, VECTORS, AND DATAFRAMES

   # OBJECTS

   x=2           # If needed, intermediate results can be saved and used later
   x
   y=sqrt(2)     # To see the saved value, just type the name of the object:
   y             # And you can use them in later calculations:
   (4+x)/2
   y**2
   z = (0:10)+x
   z

   ls()          # To recall the names you have used to save the results 'ls' stand for list
   rm(y)         # To remove one of them, type rm(name of unwanted object)
   ls()
   rm(list=ls()) # If you want to delete them all, use the command rm(list=ls())
   ls()          # then check to see what is left in your list (it should be empty)

   X=2           # R is case sensitive, e.g. object x is different from object X
   x
   x=3
   x+X
   SQRT(4)
   sqrt(4)

   x <- 32       # In addition to "=", "<-" can be used to assign a value to an object
   x+2

   1/0           # you may encounter the following: Inf, -Inf, NA, NaN
   -1/0          # Inf ~ infinitely large number
   Inf+2
   log(0)        # NA-missing (Not Available) value
   mean(c(2,3,NA))
   0/0           # NaN - Not A Number

   # VECTORS

   x <- c(1,3,2,6,10,4)   # c stands for "concatenate"
   x 
   x[3]          # Getting the third element
   x>2           # Determining which elements are greater than 2
   x[x>2]        # Getting all elements in y where y is greater than 2
  
   q <- x^3
   q
   t <- seq(1,10,2)       # seq stands for sequence: in this case,
   t                      # a sequence ranging from 1 to 10, with increment of 2
   r <- rep(1,10)         # rep stands for repetition: in this case,
   r                      # a repetition of the number 1, 10 times

   x <- rep(1,10)         # vector of 1s repeated 10 times
   x
   y <- rep(2,10)         # vector of 2s repeated 10 times
   y
   z <- rep(3,10)         # vector of 3s repeated 10 times
   z
   
   letter <- rep("A",5)   # you just created a vector of characters
   letter
   
   w <- 1:5               # the colon operator: means "a series for integers between"
   w
   
   tabcol <- cbind(x,y,z) # cbind stands for binding columns together
   tabcol                 # tabcol is a dataframe of dimensions 10 (rows) * 3 (columns)
   tabrow <- rbind(x,y,z) # rbind stands for binding rows together
   tabrow                 # tabrow is a dataframe of dimensions 3 (rows) * 10 (columns)
   
   # Note that only vectors of the same length can be bound together
   
   dim(x)      # return NULL because x is a 1 dimensional object
   length(x)   # returns 10 which is the length of vector x
   dim(tabcol) # returns 10 and 3 (10 rows, 3 columns)
   dim(tabrow) # returns 3 and 10 (3 rows, 10 columns)
   
   # IMPORTANT! rows first, columns second, ALWAYS!

# ______________________________________________________________________________

 # MANIPULATING OBJECTS AND VECTORS
 
   # NUMERIC VECTORS
   x
   x[3]          # returns the third element in vector x
   z
   z[5]          # returns the fifth element in vector x; [] are used to specify
                 # the position of an elements within a vector in this case
   tabcol[2,3]   # within a dataframe in this case, returns the value found
                 # in the second row and the third column of dataframe tabcol
                 # REMEMBER: row number first, column number second!
                 
  # CHARACTER VECTORS
  tex <- c("X","Y")
  tex
    
  # OTHER USEFUL FUNCTIONS
  tex <- paste(c("X","Y"),1:10)
  tex
  tex <- paste(c("X","Y"),1:10,sep="") # sep stands for separator
  tex            # whatever is in between quotes will be used as a separator
                 # let's try a different separator, for example:
  tex <- paste(c("X","Y"),1:10,sep="/") 
  tex            # variable tex gets overwritten each time I assign it something new
  
  head(tabcol)   # returns the first few rows of the dataframe 
  tail(tabcol)   # returns the last few rows of the dataframe 
  head(x)        # also works with vectors: returns the first few elements
  tail(x)        # returns the last few elements
                    
  # NOTE: a vector is a 1 dimensional element of a certain length
          # a data frame is a two dimensional element with associated dimensions:
          # number of rows, number of columns
  
 #______________________________________________________________________________

 # GETTING HELP

   # Use the following "?" or "help()"
   ?head
   help("dim")
   # If you are unsure about the name of a command, try apropos()
   apropos("leng")
   # If you do not know the name of the function, select from the menu
   # Help --> HTML Help
   # Help --> R manuals are very nicely done manuals that will help you get 
     # started, I posted them as readings in modules 1, 2, 3 
     # so that you don't have to read them all at once
   # Help --> FAQ in R can also provide useful information
   
# ______________________________________________________________________________

 # DEBUGGING

  # the Text editor section of RStudio limit bugs and mistakes via color scheme
  # for example, how to check that a parenthesis has been open, but not closed
  x <- 2-(3+2)/3) # parentheses missing
  x <- 2-((3+2)/3)
  # an open bracket should always be closed
  # an open quote should always be closed
  
  # The browser() function in R's base package allows you to single step through the execution of an R function. 
  # You can view and change objects during execution. There is support for setting conditional breakpoints. 

  # The debug() function marks a function for debugging, so that browser() will be called on entry. 
  # Use ?debug in R to see the man page for debug(). 

  # The trace() function modifies a function to allow debug code to be temporarily inserted. 
  # Use ?trace in R to see the man page for trace(). 

  # The findLineNum() and setBreakpoint() functions in the utils package work with line number references 
  # to compute locations for calls to trace(). 

  # Further details are given in the R Language manual in the Debugging chapter, 
  # and in Roger Peng's "An Introduction to the Interactive Debugging Tools in R".

  # if all of the above don't work out, the answer is in the error message you get! 
  # however, these message are often not very explicit, so...
    # google it!
    # even better, go to the R forum and look for you error message here:
    # http://www.r-project.org/search.html


# ______________________________________________________________________________

  # SAVING YOUR WORK
  
  # You can save all the objects you have created in R by choosing from the menu
  # File- Save Workspace
  # You can then restore all objects created during a previous session by loading the
  # Workspace
  # All commands issued during a session can be saved to Tinn-R   (File --> Save)
  # The file you created via "Save History" can be opened and edited using notepad, for example.
  # File - Save to File

# ______________________________________________________________________________

  
  

