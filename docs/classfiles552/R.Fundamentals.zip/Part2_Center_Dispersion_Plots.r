################################################################################
#                                                                              #
#                     MEASURES OF CENTER, DISPERSION, AND PLOTS                #
#                                                                              #
################################################################################


 # MEASURES OF CENTER

  x <- c(1,3,5,2,9)
  mean(x)
  x <- c(1,3,5,2,9,NA,7,10)  # If there are missing values
  mean(x)
  mean(x, na.rm=T)           # Dealing with missing values
  x <- c(155, 160, 171, 182, 162, 153, 190, 167, 168, 165, 191)
  median(x)
  x <- c(155, 160, 171, 182, 162, 153, 190, 167, 168, 165, 191, 175) 
  median(x)   
  x <- c(1,4,5,7,8,8,11)
  range(x)        # To find the mode for a discrete or categorical variable
  sort(table(x))  # make a sorted table
  
  a <- c(10, 2, 19, 24, 6, 23, 47, 24, 54, 77)
  1/mean(1/a) # Compute the harmonic mean

  a <- c(10, 2, 19, 24, 6, 23, 47, 24, 54, 77)
  n <- length(a) # n is equal to the number of elements in object a
  prod(a)^(1/n)  # Compute the geometric mean

# ______________________________________________________________________________

  # MEASURES OF DISPERSION

  var(x)              # variance
  sd(x)               # standard deviation
  x <- c(1,4,5,7,8,110) # change the last observation from 11 to 110
  var(x)              # measures of dispersion are sensitive to extremes
  sd(x)

  # In R, you can use 'quantile' function to get median and quartiles, or you can
  # also use the 'summary' fundtion to get the mean:
  quantile(x)
  summary(x)
  
  # Make a function to calculate standard errors
  se <- function(y) sd(y)/sqrt(length(y))  # note that length(y) = sample size
  x <- c(1,2,3,4)
  se(x) # here we apply the function to a vector x

# ______________________________________________________________________________

  # PLOTS

    #___________________________________________________________________________
    
    # SCATTERPLOT: 
    mass <- c(70,54,65,62,88,65,52,50)                # variable X
    height <- c(172,162,173,161,170,165,155,162)      # variable Y
    plot(mass,height)    # plot of x (x-axis) vs y (y-axis)

    #___________________________________________________________________________
    
    # TIME SERIES: human growth curve from 0 to 18 years old  "Age series"
    massBob <- c(3,12,18,22,30,38,45,58,64,70)
    age <- seq(0,18,2) 
    plot(age,massBob)
    
    plot(age,massBob,type="l",main="Bob's growth curve",xlab="Age (in years)", 
    ylab="Mass (in Kg)", xlim=c(0,20),ylim=c(0,70),lwd=2)
    # plot embellishments: 
     # type="l" = line plot
       # the "type" function:
       # "p" stands for points
       # "l" for lines
       # "h" for bars
     # main = main title of the plot, by default it is centered above the plot
     # xlab = label for the x-axis
     # ylab = label for the y-axis
     # xlim = limits or bounds to the x-axis
     # ylim = limits or bounds to the y-axis
     # c = concatenate
     # lwd = 2 thickness of the object, whether it is a series of points, lines, 
       # bars, etc (1: thin, 2: thick, 3: thicker...)
     # IMPORTANT: NOTE THAT CHARACTERS ARE ALWAYS SURROUNDED BY QUOTES
       # helps R distinguish between numerical and character values
             
    massJane <- c(3,10,15,19,26,32,40,52,54,55)
    plot(age,massBob,type="l",main="Growth curves",xlab="Age (in years)", 
    ylab="Mass (in Kg)", xlim=c(0,20),ylim=c(0,70),lwd=2, col="blue")
    lines(age,massJane,type="l",lwd=2,col="red")
    legend(x=3,y=60,legend=c("Bob","Jane"),lwd=2,col=c("blue","red"),bty="n")
      # additional embellishments
        # col = color of the "type" of object plottes 
          # in this case color of the lines
        # lines = will fit a line to the data
        # legend = wll add a legend to the plot
          # should always follow the plot or line command  
          # you have to specify coordinates x and y 
          # x and y are the coordinates for the upper-left corner of the legend
          # bty = "n" means that a box will not be drawn around the legend     

    # These are just a few basic plot command
    # for a complete list go to: par
    ? par # note that when you have a question about a specific command you can
          # ask r about it using ?
    
    #___________________________________________________________________________
    
    # BOXPLOT: weight by sex
    weight <- c(56, 67, 65, 78, 49, 87, 55, 63, 70, 72, 79, 52, 60, 78, 90, 92, 85)
    sex <- c(1,1,1,2,1,2,1,1,1,2,1,1,1,2,2,2,2)
    boxplot(weight~sex)
        # Note that the difference between plot and boxplot functions:
          # plot(x,y)
          # boxplot(y~x)
          
    sex <- factor(sex, labels=c("Females","Males"))
    boxplot(weight~sex, main="Sex-specific body weights",
    ylab="Body weight (in Kg)", col=c("pink","lightblue"))
  
    #___________________________________________________________________________
    
    # BARPLOT: eye color distributions
    eyecol <- c(1,2,1,2,2,2,3,3,1,4,2,2,2,3,1,4,3,2,1,1,1) # eye color vector
    table(eyecol) # eye color frequency table
    eyecol
    eyecol <- factor(eyecol, labels=c("blue","grey","brown","green"))
    table(eyecol) # a more meaningful table
    eyecol
    prop.table(table(eyecol)) # relative frequencies
    eyecol
    round(100*prop.table(table(eyecol)),1)
    # percentages, rounded to 1 decimal place
    eyecol
    barplot(table(eyecol)) # a simple bar chart
    barplot(table(eyecol), col=c("blue","grey","brown","green"), main="Eye color")
    
    #___________________________________________________________________________
    
    # HISTOGRAM: weights
    weight <- c(56,67,48,65,78,87,55,63,63,75,70,72,79,52,60,78,90,92, 
    82,56,69,74,63,67,59,69,56,53,68,85) 
    hist(weight, breaks=8, xlab="Weight (in Kg)") 
    # A histogram can be a poor method for determining the shape of a distribution 
    # because it is so strongly affected by the number of bins used.   
    
    # DENSITY PLOT: 
    # density plots are usually a much more effective way to view the 
    # distribution of a variable. 
    plot(density(weight), main="Density Kernel", xlab="Weight (in Kg)", lwd=2,
    col="red") 
  
# ______________________________________________________________________________

  # TO SAVE YOUR PLOTS
  plot(density(weight), main="Density Kernel", xlab="Weight (in Kg)",
  lwd=2, col="red") 
  savePlot(filename="DensityPlot",type="pdf")

# ______________________________________________________________________________

  # LAYOUTS FOR MULTIPLE PLOTS: functions par and layout 
  
  # par function: for plot layout within the graphical window
    
    # 3 plots, 3 columns & 1 row
    par(mfrow=c(1,3))   
    plot(density(weight),col="red",pch=19,main="Red Plot")
    plot(density(weight),col="blue",pch=19,main="Blue Plot")
    plot(density(weight),col="green",pch=19,main="Green Plot")
      
    # 3 plots, 3 rows & 1 column
    par(mfcol=c(3,1))
    plot(density(weight),col="red",pch=19,main="Red Plot")
    plot(density(weight),col="blue",pch=19,main="Blue Plot")
    plot(density(weight),col="green",pch=19,main="Green Plot")    

    # 5 plots, 3 columns & 2 row skipping middle of 2nd row
    par(mfrow=c(2,3))
    plot(density(weight),col="red",pch=19,main="Red Plot")
    plot(density(weight),col="blue",pch=19,main="Blue Plot")
    plot(density(weight),col="green",pch=19,main="Green Plot")  
    plot(density(weight),col="orange",pch=19,main="Orange Plot")    
    plot.new()           # add "empty" graph to cell in plot matrix
    plot(density(weight),col="yellow",pch=19,main="Yellow Plot") 
  
  # One can also use the layout function
  
    # 2X2 with rows first
    layout(matrix(c(1:4),2,2,byrow = TRUE))
    layout.show(4)

    # 2X2 with columns first
    layout(matrix(c(1:4),2,2))  
    layout.show(4)

    layout(matrix(c(1:12),2,6,byrow=T))
    layout.show(12)

# ______________________________________________________________________________
